package library;

public class ComparableBook {
    
}
