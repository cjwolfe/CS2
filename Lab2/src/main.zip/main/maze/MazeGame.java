package main.maze;

import java.util.Scanner;

public class MazeGame {
    public final int HEIGHT = 0;
    public final int WIDTH = 0;
    private final int COL = 0;
    private final int ROW = 0;

    private Scanner playerInput;
    private boolean[][] blocked;
    private boolean[][] visited;
    private int[] player;
    private int[] goal;
    private int[] start;

    public static void main(String[] args) {
        System.out.println("Nothing is working");
    }

    public MazeGame(String mazeFile) {
    }

    public MazeGame(String mazeFile, Scanner playerInput) {
    }

    public void playGame() {

    }

    public void printMaze() {

    }

    public int getPlayerRow() {
        return 0;
    }

    public int getPlayerCol() {
        return 0;
    }

    public int getGoalRow() {
        return 0;
    }

    public int getGoalCol() {
        return 0;
    }

    public int getStartRow() {
        return 0;
    }

    public int getStartCol() {
        return 0;
    }

    public boolean[][] getBlocked() {
        return null;
    }

    public boolean[][] getVisited() {
        return null;
    }

    public Scanner getPlayerInput() {
        return null;
    }

    public void setPlayerRow(int row) {

    }

    public void setPlayerCol(int col) {

    }

    public void setGoalRow(int row) {

    }

    public void setGoalCol(int col) {

    }

    public void setStartRow(int row) {

    }

    public void setStartCol(int col) {

    }

    public void setBlocked(boolean[][] blocked) {

    }

    public void setVisited(boolean[][] visited) {

    }

    public void setPlayerInput(Scanner playerInput) {

    }

    private boolean[][] copyTwoDimBoolArray(boolean[][] arrayToCopy) {
        return null;
    }

    private void prompt() {

    }

    private boolean playerAtGoal() {
        return true;
    }

    private boolean valid(int row, int col) {
        return true;
    }

    private void visit(int row, int col) {

    }

    private void loadMaze(String mazeFile) {

    }

    private boolean makeMove(String move) {
        return true;
    }
}