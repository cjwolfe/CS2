package deck;

enum Suit{
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;
}