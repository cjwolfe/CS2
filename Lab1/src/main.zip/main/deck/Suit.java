package deck;

//public class Suit {
public enum Suit {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES
    // }
}