package nature;

public interface Pet {
    // Method for the pet to play
    void play();

    // Method for the pet to show friendliness
    void beFriendly();
}
